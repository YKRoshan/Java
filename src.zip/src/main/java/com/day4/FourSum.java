package com.day4;

public class FourSum {
    public static void fun(){

    }
    public static void main(String []args){
        System.out.println();
    }
}
