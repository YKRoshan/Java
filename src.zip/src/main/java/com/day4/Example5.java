package com.day4;

public class Example5 {
    public static void fun(){

    }
    public static void main(String []args){
        System.out.println();
    }
}
